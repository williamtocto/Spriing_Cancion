package com.example.actividad_clase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActividadClaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
